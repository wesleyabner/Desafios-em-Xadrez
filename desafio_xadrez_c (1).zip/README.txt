Projeto: Desafio de Xadrez em C
Descrição: Detecta xeque-mate em uma posição simples com rei preto e dama branca.

Compilar:
    gcc main.c tabuleiro.c -o xadrez

Executar:
    ./xadrez

Autor: ChatGPT para Wesley Abner