#include <stdio.h>
#include "tabuleiro.h"

int main() {
    inicializar_tabuleiro();
    imprimir_tabuleiro();

    if (verificar_xeque_mate()) {
        printf("\nResultado: Xeque-mate!\n");
    } else {
        printf("\nResultado: Apenas em xeque.\n");
    }

    return 0;
}