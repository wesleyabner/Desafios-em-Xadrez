#include <stdio.h>
#include "tabuleiro.h"

char tabuleiro[8][8];

void inicializar_tabuleiro() {
    for (int i = 0; i < 8; i++)
        for (int j = 0; j < 8; j++)
            tabuleiro[i][j] = ' ';

    tabuleiro[0][6] = 'k'; // rei preto em g8
    tabuleiro[1][5] = 'Q'; // dama branca em f7
    tabuleiro[7][6] = 'K'; // rei branco em g1
}

void imprimir_tabuleiro() {
    printf("  A B C D E F G H\n");
    for (int i = 0; i < 8; i++) {
        printf("%d ", 8 - i);
        for (int j = 0; j < 8; j++) {
            printf("%c ", tabuleiro[i][j]);
        }
        printf("\n");
    }
}

int verificar_xeque_mate() {
    int dx[] = {-1, -1, -1, 0, 0, 1, 1, 1};
    int dy[] = {-1, 0, 1, -1, 1, -1, 0, 1};
    int rx = 0, ry = 6;

    for (int i = 0; i < 8; i++) {
        int nx = rx + dx[i];
        int ny = ry + dy[i];
        if (nx >= 0 && ny >= 0 && nx < 8 && ny < 8) {
            if (tabuleiro[nx][ny] == ' ') {
                return 0;
            }
        }
    }
    return 1;
}