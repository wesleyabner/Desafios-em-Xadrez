#ifndef TABULEIRO_H
#define TABULEIRO_H

void inicializar_tabuleiro();
void imprimir_tabuleiro();
int verificar_xeque_mate();

#endif